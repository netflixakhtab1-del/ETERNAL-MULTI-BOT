# =========================================================
#  EternalMC MultiBot - Utils Package Initializer
#  Demon Edition V4
# =========================================================

# Allow "from utils import db, embeds, permissions"
from . import db
from . import embeds
from . import permissions
from . import ip_store
